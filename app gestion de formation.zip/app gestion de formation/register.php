<?php

$u = $_POST["userName"];
$pr = $_POST["userPname"];
$ps = $_POST["passwords"];



$conn = new mysqli("localhost", "root", "","formation");
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
  
$requette = "INSERT INTO registre ( username , userpname , password) VALUES
 ('$u', '$pr','$ps')";

if ($conn->query($requette) == TRUE) {
    echo "<script language='javascript'> alert ('<h2>votre demande a ete bien enregistre ') </script> </h2>";
    header("clocation: login.php");
  } 
  else 
  {
    echo "Erreur: " . $requette . "<br>" . $conn->error;
  }
  
  $conn->close();
  }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title> My App </title>
<style>
 @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');

 * {
     margin: 10;
     padding: 0;
     box-sizing: border-box;
     font-family: 'Poppins', sans-serif
 }

 body {
     background: #ecf0f6
 }

 .wrapper {
     max-width: 400px;
     min-height: 500px;
     margin: 80px auto;
     padding: 40px 30px 40px 30px;
     background-color: #ecf0f3;
     border-radius: 15px;
     box-shadow: 13px 13px 20px #cbced1, -13px -13px 20px #fff
 }

 

 

 .wrapper .name {
     font-weight: 600;
     font-size: 1.4rem;
     letter-spacing: 1.3px;
     padding-left: 60px;
     color: #555
 }

 .wrapper .form-field input {
     width: 100%;
     display: block;
     border: none;
     outline: none;
     background: none;
     font-size: 1.2rem;
     color: #666;
     padding: 10px 15px 10px 10px
 }

 .wrapper .form-field {
     padding-left: 10px;
     margin-bottom: 20px;
     border-radius: 20px;
     box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff
 }

 .wrapper .form-field .fas {
     color: #555
 }

 .wrapper .btn {
     box-shadow: none;
     width: 100%;
     height: 40px;
     background-color: #03A9F4;
     color: #fff;
     border-radius: 25px;
     box-shadow: 3px 3px 3px #b1b1b1, -3px -3px 3px #fff;
     letter-spacing: 1.3px
 }

 .wrapper .btn:hover {
     background-color: #039BE5
 }

 .wrapper a {
  padding-left: 10px;
  
     text-decoration: none;
     font-size: 0.8rem;
     color: #03A9F4
 }

 .wrapper a:hover {
     color: #039BE5
 }

 @media(max-width: 380px) {
     .wrapper {
         margin: 30px 20px;
         padding: 40px 15px 15px 15px
     }
 }
 </style>

</head>
<body>
    <a class="btn btn-primary" href="login.php">Back</a>
<div class="wrapper">
    
    <div class="text-center mt-4 name"><h3> Sign up </h3></div>
	
    <form class="p-3 mt-3" method="post">
        <div class="form-field d-flex align-items-center"> <span class="far fa-user"></span>
		<input type="text" name="userName" id="userName" placeholder="Votre Nom" required=""> </div>
		
				        <div class="form-field d-flex align-items-center"> <span class="far fa-user"></span>
		<input type="text" name="userPname" id="userPname" placeholder="Votre Prénom" required=""> </div>
		
        <div class="form-field d-flex align-items-center"> <span class="fas fa-key"></span>
		<input type="password" name="passwords" id="pwd" placeholder="Votre mot de passe" required=""> 
		</div> <button class="btn mt-3">Sign up</button>
	
		       
    </form>
	
</div>

 </body>
 </html>