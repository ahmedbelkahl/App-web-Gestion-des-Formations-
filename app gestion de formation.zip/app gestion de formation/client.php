<?php
$conn= new mysqli("localhost","root","","formation");
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
    $n= $_POST["name"];
    $p= $_POST["cin"];
    $s= $_POST["entre"];
    $d= $_POST["select"];

$requette = " INSERT INTO client (nom, cin , entreprise, theme) VALUES
 ('$n', '$p','$s','$d')";

if ($conn->query($requette) == TRUE) {
  echo "insertion effectuer";
  header("location:login.php");
} 
else 
{
  echo "Erreur: " . $requette . "<br>" . $conn->error;
}

$conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>satge 2éme app gestion des formations</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" ></script>
        <style> 
            .wrapper {
                max-width: 700px;
                min-height: 200px;
                margin: 100px auto;
                padding: 40px 30px 40px 30px;
                background-color: #ecf0f3;
                border-radius: 15px;
                box-shadow: 13px 13px 20px #cbced1, -13px -13px 20px #fff
            }
           
           
            * {
                margin: 50;
                padding: 10;
                box-sizing:10%;
                font-family: 'Poppins'
            }
           
            
             .btn {
                box-shadow: none;
                width: 15%;
                height: 35px;
                background-color: #03A9F4;
                color: #fff;
                border-radius: 25px;
                box-shadow: 3px 3px 3px #b1b1b1, -3px -3px 3px #fff;
                letter-spacing: 1.3px
            }
           
            .btn:hover {
                background-color: #039BE5
            }
           
           
           .form-field input {
            
                width: 100%;
                display: block;
                border: none;
                outline: none;
                background: none;
                font-size: 1rem;
                color: #666;
                padding: 10px 15px 10px 5px
            }
           
            .form-field {
              width: 170px;
                height: 30px;
                padding-left: 10px;
                margin-bottom: 20px;
                border-radius: 20px;
                box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff
            }
            .form-field .fas {
                color: #555
            }
          
           
               </style>
               
    </head>
    
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" ><center class="h"><font  color=>GTS Formations</font></center></a>
            
        </nav>
        <br> 
               <br>
            <div id="layoutSidenav_content">
               
             
            <main>
                <div class="titre" >
            
                <p> <h2><center> <font color="black" align="centre"> 
                 <em>Centre Nationnal De L'informatique </em></font></center> </h2></p>
                </div>
                <div class="wrapper">
                <form method="post" action=" " width="100%" >
                <fieldset>
                <legend ><font color="#039BE5"><b>inscrit dans une Formations </b> </font> </legend>
                <table border="0" align="center">
                
                <tr> 
                <td> Nom et prenom</td>
                 <td>&nbsp;  <div class="form-field d-flex align-items-center"> <input type="text" name="name" placeholder="votre nom et prénom "/> </td>
                <td> N° cin  </td>
                 <td>&nbsp; <div class="form-field d-flex align-items-center"> <input type="text" name="cin" placeholder="numéro de cin"/> </td>
                </tr>
                <tr>
                <td> Entreprise</td> 
                <td> &nbsp;  <div class="form-field d-flex align-items-center"> <input type="text" name="entre" placeholder="Entreprise "/> </td>
                <td> Theme de Formation</td> 
                <td> &nbsp;  <select name="select" >
                    <?php 
                    $conn=new mysqli ("localhost" , "root" ,"", "formation");
                    $sql=" SELECT theme from forma " ;
                    $result = $conn->query($sql);
                    while($tab = $result->fetch_assoc())
                    {
                        echo" <option value=".$tab["theme"].">".$tab["theme"];    
                    }
                    ?>
                    </select>
                   </td>
                </tr>
             
               
                </table>
                <br>
                 <center><input class=" btn mt-3" type="submit" name="submit" value="enregistrer"/>&nbsp; &nbsp;<input class="btn mt-3" type="reset" name="reset" value="Annuler"/></center>
                
                <br>
                </fieldset>
                </form>
                
                </div>
                
                </div>


</main>
</div>
                
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
