<?php
if (isset($_POST['update'])){
    $id= $_POST['id'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$telephone = $_POST['spec'];
$adresse = $_POST['dir'];

//echo "bonjour $prenom $name";

$conn = new mysqli("localhost", "root", "","formation");


// vérifier la connexion
//if ($conn->connect_error) {
//  die("Connection failed: " . $conn->connect_error);
//}
//echo "connexion";


//-----------------------------------
$requette = "UPDATE  formateur 
SET 
nom='$nom',
prenom='$prenom',
specialite='$telephone',
direction='$adresse '
where id='$id'
"; 


          

if ($conn->query($requette) === TRUE) {
  echo "insertion effectu&eacutee";
} 
else 
{
  echo "Erreur: " . $requette . "<br>" . $conn->error;
}

$conn->close();
}
?>