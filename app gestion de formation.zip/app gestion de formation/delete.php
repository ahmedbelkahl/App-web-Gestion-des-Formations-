<?php
$conn= new mysqli("localhost","root","","formation");
if(isset($_GET['deleteid'])){ $id=$_GET['deleteid'];
$sql="delete from formateur where id=$id" ;
$result=mysqli_query($conn,$sql);
if($result){
   // echo"yyy";
   header("location:formateur.php");

}
}
?>