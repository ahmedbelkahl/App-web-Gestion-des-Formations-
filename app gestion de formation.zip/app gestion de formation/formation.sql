-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 04 Février 2022 à 13:53
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `formation`
--

-- --------------------------------------------------------

--
-- Structure de la table `authent`
--

CREATE TABLE IF NOT EXISTS `authent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `authent`
--

INSERT INTO `authent` (`id`, `username`, `password`, `usertype`) VALUES
(1, 'admin', '123', 'admin'),
(2, 'user', '123', 'user');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `cin` varchar(50) NOT NULL,
  `entreprise` varchar(50) NOT NULL,
  `theme` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `cin`, `entreprise`, `theme`) VALUES
(14, 'ahmed', '258', 'iset', '2cn'),
(15, 'DALI', '01010101', 'CNI', 'INSAF'),
(16, 'DALI1', '225', 'cni', 'INSAF');

-- --------------------------------------------------------

--
-- Structure de la table `forma`
--

CREATE TABLE IF NOT EXISTS `forma` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `actions` int(11) NOT NULL,
  `cridit` char(3) NOT NULL,
  `theme` varchar(100) NOT NULL,
  `mode` varchar(100) NOT NULL,
  `lieu` varchar(100) NOT NULL,
  `gouv` varchar(50) NOT NULL,
  `datebeb` date NOT NULL,
  `datefin` date NOT NULL,
  `tempsd` time NOT NULL,
  `tempsf` time NOT NULL,
  `paused` time NOT NULL,
  `pausef` time NOT NULL,
  `formateur` varchar(50) NOT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `forma`
--

INSERT INTO `forma` (`num`, `actions`, `cridit`, `theme`, `mode`, `lieu`, `gouv`, `datebeb`, `datefin`, `tempsd`, `tempsf`, `paused`, `pausef`, `formateur`) VALUES
(24, 1, 'on', 'INSAF', 'INTER ENTREPRISE', 'cni', 'tunis', '2022-01-31', '2022-02-04', '08:30:00', '14:30:00', '11:30:00', '12:00:00', 'mohamed'),
(25, 2258, 'on', 'INSAF', 'INTER ENTREPRISE', 'cni', 'tunis', '2022-02-01', '2022-02-06', '08:45:00', '13:45:00', '11:46:00', '12:46:00', 'kamel');

-- --------------------------------------------------------

--
-- Structure de la table `formateur`
--

CREATE TABLE IF NOT EXISTS `formateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `specialite` varchar(50) NOT NULL,
  `direction` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Contenu de la table `formateur`
--

INSERT INTO `formateur` (`id`, `nom`, `prenom`, `specialite`, `direction`) VALUES
(66, 'fraj', 'cherni', 'reseaux', 'reseaux'),
(67, 'mohamed', 'sadek', 'informa', 'informatique'),
(68, 'kamel', 'ali', 'gestion', 'nnn');

-- --------------------------------------------------------

--
-- Structure de la table `registre`
--

CREATE TABLE IF NOT EXISTS `registre` (
  `username` varchar(50) NOT NULL,
  `userpname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `registre`
--

INSERT INTO `registre` (`username`, `userpname`, `password`) VALUES
('', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
