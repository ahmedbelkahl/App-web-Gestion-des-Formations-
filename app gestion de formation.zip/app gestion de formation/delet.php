<?php
$conn= new mysqli("localhost","root","","formation");
if(isset($_GET['deleteid'])){ $id=$_GET['deleteid'];
$sql="delete from forma where num=$id" ;
$result=mysqli_query($conn,$sql);
if($result){
   // echo"yyy";
   header("location:formation.php");

}
}
?>